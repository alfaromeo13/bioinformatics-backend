#ifndef DOMDEC_GPU_H
#define DOMDEC_GPU_H

#include "MDsim.h"

/*
extern int num_blocks;
extern cudaStream_t enb_stream;
#ifdef USE_STREAM
extern cudaEvent_t nbond_force_done_event;
extern cudaEvent_t force_copy_done_event;
#endif

*/

extern MDsim *mdsim;

#endif // DOMDEC_GPU_H
