#ifndef OPENMM_MSES_H_
#define OPENMM_MSES_H_

#include "MSESForce.h"

#endif /*OPENMM_MSES_H_*/
