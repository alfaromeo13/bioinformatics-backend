#ifndef OPENMM_GBMV_H_
#define OPENMM_GBMV_H_

/* -------------------------------------------------------------------------- *
 *                               OpenMMGBMV                                   *
 * -------------------------------------------------------------------------- */

#include "GBMVForce.h"

#endif /*OPENMM_GBMV_H_*/
