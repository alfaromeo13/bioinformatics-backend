#ifndef UPDATE_REX_H
#define UPDATE_REX_H

#include "main/defines.h"

#ifdef REPLICAEXCHANGE
// Forward declarations
class System;

void replica_exchange(System *system);
#endif

#endif
