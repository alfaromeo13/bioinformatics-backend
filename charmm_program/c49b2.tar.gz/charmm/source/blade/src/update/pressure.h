#ifndef UPDATE_PRESSURE_H
#define UPDATE_PRESSURE_H

// Forward declarations
class System;

void pressure_coupling(System *system);

#endif
