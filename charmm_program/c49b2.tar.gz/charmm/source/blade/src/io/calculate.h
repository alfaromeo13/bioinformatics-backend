#ifndef IO_CALCULATE_H
#define IO_CALCULATE_H

#include "main/defines.h"

real variables_calculate(char *line);

#endif
